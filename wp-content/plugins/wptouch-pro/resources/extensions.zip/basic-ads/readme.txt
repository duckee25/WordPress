Extension Name: Basic Ads
Extension URI: http://www.wptouch.com/extensions/basic-ads
Author: BraveNewCode Inc.
Description: Basic advertising extension that allows you to easily show an ad from Google Adsense, or your own custom script.
Version: 1.1
Depends-on: 4.0

== Long Description ==

Basic Ads allows you to show advertising from Google Adsense, or your own custom ad script. Easily add your code and select where you'd like your advertising shown. For multiple ad slots, along with A/B testing, purchase the Multi-Ads extension.

== Changelog ==

= Version 1.1.1 =

* Changed: Replace call to foundation_get_settings()

= Version 1.1 =

* Added: Support for the new AMP extension (Google Ads only)

= Version 1.0 =

* Initial release for WPtouch 4