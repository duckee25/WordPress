<?php $settings = wptouch_get_settings( 'foundation' ); ?>
<script async src="http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle" style="display:inline-block;width:320px;height:50px" data-ad-client="<?php echo trim( $settings->google_adsense_id ); ?>" data-ad-slot="<?php echo trim( $settings->google_slot_id ); ?>"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>